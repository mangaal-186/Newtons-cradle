class Rope{
    constructor(bodyA, bodyB, offsetX, offsetY){
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        var options={
            bodyA: bodyA,
            bodyB: bodyB,
            pointB: {x: this.offsetX, y:this.offsetY}
        }
        this.rope = Constraint.create(options);
        World.add(world, this.rope);
    }
    display(){
        var pointA = this.rope.bodyA.position;
        var pointB = this.rope.bodyB.position;
        strokeWeight(2);
        stroke("black");
        fill(0);

        var Anchor1X = pointA.x;
        var Anchor1Y = pointA.y;

        var Anchor2X = pointB.x+this.offsetX;
        var Anchor2Y = pointB.y+this.offsetY;

        line(Anchor1X, Anchor1Y, Anchor2X, Anchor2Y);
    }
}
//startBobPositionX=width/2; startBobPositionY=height/4+500; bobObject1=new bob(startBobPositionX-bobDiameter*2,startBobPositionY,bobDiameter); bobObject2=new bob(startBobPositionX-bobDiameter,startBobPositionY,bobDiameter); bobObject3=new bob(startBobPositionX,startBobPositionY,bobDiameter); bobObject4=new bob(startBobPositionX+bobDiameter,startBobPositionY,bobDiameter); bobObject5=new bob(startBobPositionX+bobDiameter*2,startBobPositionY,bobDiameter);